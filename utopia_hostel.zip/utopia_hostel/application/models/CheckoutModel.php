<?php

class CheckoutModel extends CI_Model {
    
    public function __construct(){
		parent::__construct();
		$this->load->database();
		$this->load->helper('url');
		$this->load->helper(array('form', 'url'));
	}
public function exibirCheckins(){
		
		$selecionarTodos=$this->db->select("age.ageCodigo,
		age.cliCodigo,
		age.quaCodigoQuarto,
		age.ageQtdPessoas,
		age.ageStatus, 
		age.ageDataCheckin,
		age.ageDataCheckout,
		age.ageValorAberto,
		cli.cliCodigo,
		cli.cliNome,
		cli.cliRG,
		cli.cliCPF,
		qua.quaCodigoQuarto,
		qua.quaNomeQuarto")
	->join("Quartos qua","qua.quaCodigoQuarto=age.quaCodigoQuarto")
	->join("Clientes cli","cli.cliCodigo=age.cliCodigo")
	->where("ageStatus", 1)
	->get("Agendamentos age");
	
		if($selecionarTodos->num_rows()>0){
		return $selecionarTodos->result_array();

		}else{
			$error = $this->db->error();
			return NULL;
		}
	}


    public function confirmaCheckout($atualizaAgendamento){
//		print_r($atualizaAgendamento);

		$atualizaValores = $this->db->query("UPDATE Agendamentos 
		SET ageValorPago = (ageValorPago + {$atualizaAgendamento['ageValorPago']}), 
		ageValorAberto = (ageValorTotal-ageValorPago), ageStatus = {$atualizaAgendamento['ageStatus']} WHERE ageCodigo = {$atualizaAgendamento['ageCodigo']}");
       // print_r($this->db->last_query()); 

    }
}