<?php

class AgendamentoModel extends CI_Model {
    
    public function __construct(){
		parent::__construct();
		$this->load->database();
		$this->load->helper('url');
		$this->load->helper(array('form', 'url'));
	}
    
    public function cadastrarAgendamento($dadosAgendamento){ //manda o array como parametro aqui
        $this->db->insert("Agendamentos",$dadosAgendamento);
    }

    public function exibirAgendamentos(){
		
		$selecionarTodos=$this->db->select("age.ageCodigo,
		age.cliCodigo,
		age.quaCodigoQuarto,
		age.ageQtdPessoas,
		age.ageStatus, 
		age.ageDataCheckin,
		age.ageDataCheckout,
		age.ageValorAberto,
		cli.cliCodigo,
		cli.cliNome,
		cli.cliRG,
		cli.cliCPF,
		qua.quaCodigoQuarto,
		qua.quaNomeQuarto")
	->join("Quartos qua","qua.quaCodigoQuarto=age.quaCodigoQuarto")
	->join("Clientes cli","cli.cliCodigo=age.cliCodigo")
	->where("ageStatus", NULL)
	->get("Agendamentos age");
	
		if($selecionarTodos->num_rows()>0){
		return $selecionarTodos->result_array();

		}else{
			$error = $this->db->error();
			return NULL;
		}
	}

	public function totaisPorQuarto30dias(){

	$selecionarTodos = $this->db->query("SELECT COUNT(qua.quaNomeQuarto) qtdquarto, qua.quaNomeQuarto nomequarto FROM Agendamentos age inner join
	 Quartos qua on qua.quaCodigoQuarto = age.quaCodigoQuarto  WHERE ageDataCheckin BETWEEN CURDATE() AND (CURDATE() + INTERVAL 30 DAY) GROUP BY qua.quaCodigoQuarto");

		if($selecionarTodos->num_rows()>0){
		//return $selecionarTodos;
		return $selecionarTodos->result();
		}else{
			/*$retorno = "Não há dados disponiveis!";*/
			return NULL;
		}
	}

	
	public function exibirAgendamento7dias(){
		//vai carregar agendamento de hj
		$selecionarTodos=$this->db->query("SELECT * FROM Agendamentos WHERE ageDataCheckin BETWEEN CURDATE() AND (curdate() + interval 7 day)");
		
		if($selecionarTodos->num_rows()>0){
			return $selecionarTodos->result_array();
		}
	}

	public function exibirAgendamento2dias(){
		//vai carregar agendamento de hj
		$selecionarTodos=$this->db->query("SELECT * FROM Agendamentos WHERE ageDataCheckin BETWEEN CURDATE() AND (CURDATE() + INTERVAL 2 day)");
		
		if($selecionarTodos->num_rows()>0){
			return $selecionarTodos->result_array();
		}
	}

	public function exibirAgendamento30dias(){
		//vai carregar agendamento de hj
		$selecionarTodos=$this->db->query("SELECT COUNT(ageCodigo), MONTH(ageDataCheckin) 
		as mes FROM Agendamentos WHERE ageDataCheckin BETWEEN CURDATE() 
		AND (curdate() + interval 30 day) GROUP BY MONTH(ageDataCheckin)");
		
		if($selecionarTodos->num_rows()>0){
			return $selecionarTodos->result_array();
		}
	}

	public function exibirAgendamento30diasCodigo(){
		$selecionarTodos=$this->db->query("SELECT*FROM Agendamentos WHERE ageDataCheckin BETWEEN CURDATE() 
		AND (curdate() + interval 30 day)");
		
		if($selecionarTodos->num_rows()>0){
			return $selecionarTodos->result_array();
		}
	}

	public function exibirAgendamento365dias(){
		$selecionarTodos=$this->db->query("SELECT  MONTH(ageDataCheckin) 
		as mes, SUM(ageValorPago) as valorpago, SUM(ageValorTotal) as valortotal, SUM(ageValorAberto) as valoraberto FROM Agendamentos WHERE ageDataCheckin BETWEEN CURDATE() 
		AND (curdate() + interval 365 day) GROUP BY MONTH(ageDataCheckin)");
		
		if($selecionarTodos->num_rows()>0){
			return $selecionarTodos->result_array();
		}
	}


	public function exibirAgendamentoDia(){
		//vai carregar agendamento de hj
		$this->db
		->from("Agendamentos")
		->where("ageDataCheckin",today());
		$selecionarTodos = $this->db->get();
		if($selecionarTodos->num_rows()>0){
			return $selecionarTodos->result_array();
		}else{
			$error = $this->db->error();
		}
	}

	public function atualizaValores($atualizaAgendamento){
		print_r($atualizaAgendamento);

		$atualizaValores = $this->db->query("UPDATE Agendamentos 
		SET ageValorPago = (ageValorPago + {$atualizaAgendamento['ageValorPago']}), 
		ageValorAberto = (ageValorTotal-ageValorPago), ageStatus = {$atualizaAgendamento['ageStatus']} WHERE ageCodigo = {$atualizaAgendamento['ageCodigo']}");
//print_r($this->db->last_query());    

	}

	public function faixa1994(){
		$faixa94 = $this->db->query("SELECT count(datediff(now(),cliNascimento)) as faixa94 FROM Clientes WHERE cliNascimento BETWEEN '1994-01-01' AND (now()-interval 18 year)");
		// $faixa94 = $this->db->get();
		if($faixa94->num_rows()>0){
			//print_r($this->db->last_query());    

			return $faixa94->result();

		}else{
			$error = $this->db->error();
		}
	}

	public function faixa1984(){
		$faixa84=$this->db->query("SELECT count(datediff(now(),cliNascimento)) as faixa84 FROM Clientes WHERE cliNascimento BETWEEN '1984-01-01' AND '1994-01-01'");
		// $faixa84 = $this->db->get();
		if($faixa84->num_rows()>0){
			//print_r($this->db->last_query());    

			return $faixa84->result();

		}else{
			$error = $this->db->error();
		}
	}

	public function faixa1974(){
		$faixa74=$this->db->query("SELECT count(datediff(now(),cliNascimento)) as faixa74 FROM Clientes WHERE cliNascimento BETWEEN '1974-01-01' AND '1984-01-01'");
		//$faixa74 = $this->db->get();
		if($faixa74->num_rows()>0){
			//print_r($this->db->last_query());    

			return $faixa74->result();

		}else{
			$error = $this->db->error();
		}
	}

	public function faixa1964(){
		$faixa74=$this->db->query("SELECT count(datediff(now(),cliNascimento)) as faixa64 FROM Clientes WHERE cliNascimento BETWEEN '1964-01-01' AND '1974-01-01'");
		//$faixa74 = $this->db->get();
		if($faixa74->num_rows()>0){
			//print_r($this->db->last_query());    

			return $faixa74->result();

		}else{
			$error = $this->db->error();
		}
	}

	

	
}
