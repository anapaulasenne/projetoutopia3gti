<?php

class ClienteModel extends CI_Model {
    
    public function __construct(){
		parent::__construct();
		$this->load->database();
		$this->load->helper('url');
		$this->load->helper(array('form', 'url'));


	}
    
    public function cadastrarClientes($dadosCliente){ //manda o array como parametro aqui
        $cadastro = $this->db->insert("Clientes",$dadosCliente);
    }

	public function validarCliente($dadosCliente){
		//print_r($dadosCliente);
		//verificar se o nome e o rg, email, cpf
		//refazer o sql pela forma normal
		$this->db
		->from("Clientes")
		->where("cliNome",$dadosCliente['cliNome'])
		->or_where("cliCPF",$dadosCliente['cliCPF'])
		->or_where("cliRG", $dadosCliente['cliRG'])
		->or_where("cliEmail", $dadosCliente['cliEmail']);

		$validacaoCliente=$this->db->get();
		if($validacaoCliente->num_rows()>0){
			return $validacaoCliente->row();
		}else{
			return NULL;
		}
	}

	public function exibirClientes(){
		//vai carregar todos os clientes
		$this->db
		->from("Clientes");
		$selecionarTodos = $this->db->get();
		if($selecionarTodos->num_rows()>0){
			return $selecionarTodos;
		}else{
			return NULL;		

		}
	}

	//validar
	public function buscarCodigoCliente($cliNome){
		//vai carregar todos os clientes
		$this->db->select("cliCodigo");
		$this->db
		->from("Clientes")
		->where("cliNome",$cliNome);
	$clienteCodigo = $this->db->get();
	$codigocliente = $clienteCodigo->row();
	if($codigocliente){
			return $codigocliente->cliCodigo;			
		}else{
			return NULL;
		}
	}

}