<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Lato:ital,wght@0,100;0,300;0,400;0,700;0,900;1,100;1,300;1,400;1,700;1,900&display=swap" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="<?= base_url().'public/css/checkin.css'?>">
    <link rel="stylesheet" type="text/css" href="<?= base_url().'public/css/menulateral.css'?>">
    <link rel="stylesheet" type="text/css" href="<?= base_url().'public/css/agendamento.css'?>">
    <link rel="stylesheet" type="text/css" href="<?= base_url().'public/css/charts.css'?>">
    <link rel="stylesheet" type="text/css" href="<?= base_url().'public/css/dashboard.css'?>">

    <script src="<?= base_url().'public/js/charts/highcharts.js'?>"></script>
    <script src="<?= base_url().'public/js/charts/a11yChart.js'?>"></script>
    <script src="<?= base_url().'public/js/charts/seriesLabel.js'?>"></script>
    <script src="<?= base_url().'public/js/charts/exportData.js'?>"></script>
    <script src="<?= base_url().'public/js/charts/exporting.js'?>"></script>
    <script src="<?= base_url().'public/js/charts/offlineExporting.js'?>"></script>
  <script src="<?= base_url().'public/js/jquery.min3.6.js'?>"></script>


    <link rel="stylesheet" type="text/css" href="index.html">
<!-- VER O HIGHCHARTS-->

    
    <title>Dashboard</title>
</head>
<body>
  <div class="app">
    <div class="sidebar">
        <div class="logo_content">
            <div class="logo">
                <div class="logo_name">Utopia Hostel</div>
            </div>
            <i class='bx bx-menu bx-flip-horizontal' id="btn" ></i>
        </div>
        <ul class="nav_list">
            <li>
                <a href="<?=base_url().'index.php/cadastrarAgendamento'?>">
                    <i class='bx bx-book'></i>
                    <span class="links_name">Agendamento</span>
                </a>
                <span class="tooltip">Agendamento</span>
            </li>
            <li>
                <a href="<?=base_url().'index.php/exibeAgendamentos'?>">
                    <i class='bx bx-calendar-check'></i>
                    <span class="links_name">Check-in</span>
                </a>
                <span class="tooltip">Check-in</span>
            </li>
            <li>
            <a href="<?=base_url().'index.php/checkout'?>">
                    <i class='bx bx-exit'></i>
                    <span class="links_name">Check-out</span>
                </a>
                <span class="tooltip">Check-out</span>
            </li>
            <li>
            <a href="<?=base_url().'index.php/dashboard'?>">
            <i class='bx bx-line-chart'></i>
                    <span class="links_name">Dashboard</span>
                </a>
                <span class="tooltip">Dashboard</span>
            </li>
        </ul>
    </div>
    <div>
<div class="agd">   
<div class="alinha titulo-icon">
                <i class='bx bx-line-chart'></i>
                <h1 id="titulo">Dashboard</h1> 
              </div>
            <div class="agd-chart-title">
                <h2>Nome da Dashboard</h2>
            </div>
        <div class="agd-content">
        <div class="agd-content-charts">              
<figure class="highcharts-figure" id="gpie" data-opt="pie">
    <p class="highcharts-description">
    </p>
    <div id="containerPie"></div>
</figure>
</div>
<div class="agd-content-charts">
<figure class="highcharts-figure" id="gbar" data-opt="bar">
    <p class="highcharts-description">
    </p>
    <div id="containerBar"></div>
</figure>
</div>

<div class="agd-content-charts">
<figure class="highcharts-figure" id="gline" data-opt="line">
    <p class="highcharts-description">
    </p>
    <div id="containerLine"></div>
</figure>
</div>

<div class="agd-content-charts">
<figure class="highcharts-figure" id="linepreco" data-opt="lineP">
    <p class="highcharts-description">
    </p>
    <div id="containerLinePrice"></div>
</figure>
</div>

<div class="agd-content-charts">
<figure class="highcharts-figure" id="barfaixa" data-opt="barFaixa">
    <p class="highcharts-description">
    </p>
    <div id="containerBar"></div>
</figure>
</div>
</div>
   <!-- <div class="agd-content-button">
<button type="button" class="botaoagd"  id="pie">Quartos</button>
<button type="button" class="botaoagd"  id="line">Reservas</button>
<button type="button" class="botaoagd"  id="lineP">Preço Reservas</button>
<button type="button" class="botaoagd"  id="barfaixa">Faixa Etária</button>
</div>
</div> -->


</body>
<script>
//   $(document).ready(function () {
//   $("#gpie").css("display","none");
//  // $("#gbar").css("display","none");
//   $("#gline").css("display","none");
//   $("#linepreco").css("display","none");
//   $("#barfaixa").css("display","none");

// $( "#pie" ).click(function() {
//   $("#gpie").css("display","block");
//   //$("#gbar").css("display","none");
//   $("#gline").css("display","none");
//   $("#linepreco").css("display","none");
//   $("#barfaixa").css("display","none");

// });
// $( "#bar" ).click(function() {
//  // $("#gbar").css("display","block");
//   $("#gpie").css("display","none");
//   $("#gline").css("display","block");
//   $("#linepreco").css("display","none");
//   $("#barfaixa").css("display","none");


// });
// $( "#line" ).click(function() {
//   $("#gline").css("display","block");
//   $("#gbar").css("display","none");
//   $("#gpie").css("display","none");
//   $("#linepreco").css("display","none");
//   $("#barfaixa").css("display","none");

// });
// $( "#lineP" ).click(function() {
//   $("#gline").css("display","none");
//   $("#gbar").css("display","none");
//   $("#gpie").css("display","none");
//   $("#linepreco").css("display","block");
//   $("#barfaixa").css("display","none");

// });

// $( "#linep" ).click(function() {
//   $("#gline").css("display","none");
//   $("#gbar").css("display","none");
//   $("#gpie").css("display","none");
//   $("#linepreco").css("display","none");
//   $("#barfaixa").css("display","block");

// });
//});
  </script>
<script>
<?php 
$this->load->model("AgendamentoModel");
$total = $this->AgendamentoModel->totaisPorQuarto30dias();
$teste = [];
$soma = 0;
foreach($total as $tot){
   $teste[] = array('qtdquarto'=>$tot->qtdquarto,
                    'nomequarto'=>$tot->nomequarto);
                    $soma += $tot->qtdquarto; 
}

//$dados = json_encode($teste);
?>

Highcharts.chart('containerPie', {
  exporting: {
        chartOptions: { 
            plotOptions: {
                series: {
                    dataLabels: {
                        enabled: true
                    }
                }
            }
        },
        fallbackToExportServer: false
    },
  chart: {
    plotBackgroundColor: null,
    plotBorderWidth: null,
    plotShadow: false,
    type: 'pie',
    height: 500
  },
  title: {
    text: 'QUARTOS'
  },
  tooltip: {
    pointFormat: '{series.name}: <b>{point.x}</b>'
  },
  accessibility: {
    point: {
      valueSuffix: '%'
    }
  },
  plotOptions: {
    pie: {
      allowPointSelect: true,
      cursor: 'pointer',
      dataLabels: {
        enabled: true,
        format: '<b>{point.name}</b>:<b>{point.percentage:.1f}%</b></b>'
      }
    }
  },
    series: [{
    name: 'Quartos',
    colorByPoint: true,
    data: [
            <?php for($i=0;$i<sizeof($teste);$i++){?>
        {
      name: <?php echo  "'".$teste[$i]['nomequarto']."'"; ?>,
      y:   <?php echo $teste[$i]['qtdquarto']/$soma*100; ?>,
      x:   <?php echo $teste[$i]['qtdquarto'] ?>,
        },
    <?php } ?>]
    }]
  
});


</script>

<script>
<?php 
$this->load->model("AgendamentoModel");
$datas = $this->AgendamentoModel->exibirAgendamento30dias();

$soma = 0;

$datas = array_column($datas,'COUNT(ageCodigo)');
//print_r($datas);

$tamanho = sizeof($datas);
$ano = 12 - $tamanho;

$reserva = array_fill($tamanho,$ano,0);

$keys = array();
for($i=$tamanho; $i<12;$i++){
  array_push($keys,$i);
}
$reservas=array_fill_keys($keys, 0);
//print_r($reservas);
 $qtdreservas = array_merge($datas,$reservas);
 //print_r($qtdreservas);
?>

Highcharts.chart('containerLine', {

title: {
    text: 'Reservas por mes'
},
chart: {
    plotBackgroundColor: null,
    plotBorderWidth: null,
    plotShadow: false,
    type: 'line',
    height: 500,
    align: 'center',
   // verticalAlign:'center',
  },
rangeSelector : {
                selected : 1
            },
            xAxis: {
                type: 'datetime',
                tickInterval: 1000 * 3600 * 24 *30
            },
            yAxis: {
        title: {
            text: 'Quantidade de Reservas'
              }
            },
            series : [{
              colorByPoint: true,
              colors: 'ae92e6',
                type: 'line',
                name: 'Reservas',
                data : [
               <?php 
               //fazer foreach para iterar o mes
               $dt = new DateTime('first day of last month');
               $data = $dt->format('Y,m,d');
            for ($i = 0; $i < 12; $i++) {
                  ?>
                    {
                    name: Date.UTC(<?=  $dt->format('Y,m,d') ?>),
                     x:  Date.UTC(<?= $dt->format('Y,m,d') ?>), 
                     /*tenho q entender como pegar os dados aqui  ver having*/
                     y: <?php //if(empty($qtdreservas['COUNT(ageCodigo)']) == false){
                       if($qtdreservas > 0){
                       echo $qtdreservas[$i];
                       }else{
                        echo $qtdreservas[$i];
                       }
                      ?>
                     <?php $dt->modify('-1 month');?>
                    },
           <?php } ?>   
            ],                
            }],

responsive: {
    rules: [{
        condition: {
            maxWidth: 500
        },
    }]
}

});


</script>

<script>
<?php 
$this->load->model("AgendamentoModel");
$valores = $this->AgendamentoModel->exibirAgendamento365dias();

$soma = 0;
$valorTotal = array_column($valores,'valortotal');
$valorPago = array_column($valores,'valorpago');
$valorAberto = array_column($valores,'valoraberto');
//print_r($valores);

$tamanho = sizeof($valores);
$ano = 12 - $tamanho;

$reserva = array_fill($tamanho,$ano,0);

$keys = array();
for($i=$tamanho; $i<12;$i++){
  array_push($keys,$i);
}
$valoresreservas=array_fill_keys($keys, 0);
//print_r($valoresreservas);
 $valorTotalReservas = array_merge($valorTotal,$valoresreservas);
 $valorPagoReservas = array_merge($valorPago,$valoresreservas);
 $valorAbertoReservas = array_merge($valorAberto,$valoresreservas);

 //print_r($valorreservas);
?>
Highcharts.chart('containerLinePrice', {

title: {
    text: 'Preco Reservas por mes'
},
chart: {
    plotBackgroundColor: null,
    plotBorderWidth: null,
    plotShadow: false,
    type: 'line',
    height: 500
  },
rangeSelector : {
                selected : 1
            },
            xAxis: {
                type: 'datetime',
                tickInterval: 1000 * 3600 * 24 *30
            },
            yAxis: {
        title: {
            text: 'Valor em R$'
              }
            },
            series : [{
              colorByPoint: false,
             // colors: '#ae92e6',
                type: 'line',
                name: 'Total',
                data : [
               <?php 
               //fazer foreach para iterar o mes
               $dt = new DateTime('first day of last month');
               $data = $dt->format('Y,m,d');
            for ($i = 0; $i < 12; $i++) {
                  ?>
                    {
                    name: Date.UTC(<?=  $dt->format('Y,m,d') ?>),
                     x:  Date.UTC(<?= $dt->format('Y,m,d') ?>), 
                     /*tenho q entender como pegar os dados aqui  ver having*/
                     y: <?php //if(empty($qtdreservas['COUNT(ageCodigo)']) == false){
                       if($valorTotalReservas > 0){
                       echo $valorTotalReservas[$i];
                       }else{
                        echo $valorTotalReservas[$i];
                       }
                      ?>
                     <?php $dt->modify('-1 month');?>
                    },
           <?php } ?>   
            ],                
            },
            {
              colorByPoint: false,
              //colors: '#FF4500',
                type: 'line',
                name: 'Pago',
                data : [
               <?php 
               //fazer foreach para iterar o mes
               $dt = new DateTime('first day of this month');
               $data = $dt->format('Y,m,d');
            for ($i = 0; $i < 12; $i++) {
                  ?>
                    {
                    name: Date.UTC(<?=  $dt->format('Y,m,d') ?>),
                     x:  Date.UTC(<?= $dt->format('Y,m,d') ?>), 
                     /*tenho q entender como pegar os dados aqui  ver having*/
                     y: <?php //if(empty($qtdreservas['COUNT(ageCodigo)']) == false){
                       if($valorPagoReservas > 0){
                       echo $valorPagoReservas[$i];
                       }else{
                        echo $valorPagoReservas[$i];
                       }
                      ?>
                     <?php $dt->modify('-1 month');?>
                    },
           <?php } ?>   
            ],                
            },
            {
              colorByPoint: false,
              //colors: '#FF4500',
                type: 'line',
                name: 'Aberto',
                data : [
               <?php 
               //fazer foreach para iterar o mes
               $dt = new DateTime('first day of this month');
               $data = $dt->format('Y,m,d');
            for ($i = 0; $i < 12; $i++) {
                  ?>
                    {
                    name: Date.UTC(<?=  $dt->format('Y,m,d') ?>),
                     x:  Date.UTC(<?= $dt->format('Y,m,d') ?>), 
                     /*tenho q entender como pegar os dados aqui  ver having*/
                     y: <?php //if(empty($qtdreservas['COUNT(ageCodigo)']) == false){
                       if($valorAbertoReservas > 0){
                       echo $valorAbertoReservas[$i];
                       }else{
                        echo $valorAbertoReservas[$i];
                       }
                      ?>
                     <?php $dt->modify('-1 month');?>
                    },
           <?php } ?>   
            ],                
            }
          ],

responsive: {
    rules: [{
        condition: {
            maxWidth: 500
        },
    }]
}

});


</script>

<script>

<?php 
$this->load->model("AgendamentoModel");
$datas94 = $this->AgendamentoModel->faixa1994();
$datas84 = $this->AgendamentoModel->faixa1984();
$datas74 = $this->AgendamentoModel->faixa1974();
$datas64 = $this->AgendamentoModel->faixa1964();




$qtdIdade = array_merge($datas94,$datas84, $datas74,$datas64);
$qtdIdade = json_decode( json_encode($qtdIdade), true);

//print_r($qtdIdade);
 ?>

Highcharts.chart('containerBar', {

title: {
    text: 'Faixa Etária'
},
chart: {
    plotBackgroundColor: null,
    plotBorderWidth: null,
    plotShadow: false,
    type: 'column',
    height: 500,
    align: 'center',
   // verticalAlign:'center',
  },
            xAxis: {
              categories:[
                '18 a 28 anos',
                '28 a 38 anos',
                '38 a 48 anos',
                '48 a 58 anos',
              ],
            },
            yAxis: {
        title: {
            text: 'Idade'
              }
            },
            series : [{
              type: 'column',

                 name:"18 a 28 anos",
                  data: [<?= $qtdIdade[0]['faixa94']; ?>]                                    
                  },
                  {
                    type: 'column',

                  name:"28 a 38 anos",
                  data: [<?= $qtdIdade[1]['faixa84']; ?> ]   
                  },
                  {
                    type: 'column',
                 name:"38 a 48 anos",
                   data: [<?= $qtdIdade[2]['faixa74']; ?>]   
                    },{
                  type: 'column',
                 name:"48 a 58 anos",
                   data: [<?= $qtdIdade[3]['faixa64']; ?>]   
                    }],

responsive: {
    rules: [{
        condition: {
            maxWidth: 500
        },
    }]
}

});


</script>
</html>