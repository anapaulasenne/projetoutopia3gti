<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="<?= base_url().'public/css/nvcliente.css'?>">
    <link rel="stylesheet" type="text/css" href="<?= base_url().'public/css/snackbar.css'?>">

    <title>Novo cliente</title>
</head>
<body> 

  <!--<a href="<?= base_url().'index.php/Cliente/#abrirmodal'?>" id="abrirModal">Abrir modal</a>-->

  <!--MODAL-->
  <div id="abrirmodal">
    <div class="conteudoModal">
      <div class="titleinitial">
        <h1 id="titulo">CADASTRAR NOVO CLIENTE</h1>
    </div>
 <?php   echo validation_errors();     ?>
 <?php if(isset($mensagensErro)) echo "<div class='snackbar-erro' >".$mensagensErro."</div>"; ?>
    <?php if(isset($mensagensSucesso)) echo "<div class='snackbar-sucesso'>".$mensagensSucesso."</div>"; ?>

        <?php echo form_open('index.php/Cliente/cadastrarClientes'); ?>
          <div class="clt alinha">
              <label for="cliente">NOME:</label>
              <input type="text" id="cliente" name="cliNome" required placeholder=" Insira seu nome completo">    
          </div>
  
          <div class="clt alinha-cpf">
              <br> <label for="cpfcliente">CPF: </label>
              <input type="text" id="cpfcliente"  class="cpf" name="cliCPF" required placeholder="xxx.xxx.xxx-xx"  onblur="ValidaCPF(this)">  
          </div>
          <small hidden class="feedback-invalido" style="text-align: center;" id="invalid">CPF invalido, por favor digite um cpf válido</small>
          <div class="clt alinha">
              <br> <label for="rg">RG:</label>
              <input type="text" id="rgcliente" name="cliRG" class="rg" required placeholder="xx.xxx.xxx-x">
          </div>
          
          <div class="clt alinha">
              <label for="telefone">TEL:</label>
              <input type="tel" id="telcliente" class="telefone" name="cliTelefone" required placeholder="(xx)XXXX-XXXX"> 
              <label for="celular">CEL:</label>
             <input type="tel" id="celcliente"  class="sp_celphones" name="cliCelular" required placeholder="(xx) 9XXXX-XXXX">    
          </div>
          <div class="clt alinha">
            <label for="email" >EMAIL:</label>
             <input type="email" id="emailcliente" required placeholder="xxxxxxx@xxx.com" name="cliEmail">  
          </div>
          <div class="clt alinha">
            <label for="checkin">DATA NASCIMENTO: </label>
            <input type="date" class="date" id="nascimento" name="cliNascimento" max="<?= date('2004-m-d')?>" required style="border-color: #341671;">
          </div>
          <div class="clt alinha" style="width: 20pc; padding:0; border-color: #341671;">
          
              <label for="cidade">CIDADE:</label>
              <input type="text" id="cidadecliente"  name="cliCidade" style="border-color: #341671;"> 
              <label for="estado">ESTADO</label>
            <select name="cliEstado" id="cliEstado">
    <option value="NULL">Selecione</option>
    <option value="AC">Acre</option>
    <option value="AL">Alagoas</option>
    <option value="AP">Amapá</option>
    <option value="AM">Amazonas</option>
    <option value="BA">Bahia</option>
    <option value="CE">Ceará</option>
    <option value="DF">Distrito Federal</option>
    <option value="ES">Espírito Santo</option>
    <option value="GO">Goiás</option>
    <option value="MA">Maranhão</option>
    <option value="MT">Mato Grosso</option>
    <option value="MS">Mato Grosso do Sul</option>
    <option value="MG">Minas Gerais</option>
    <option value="PA">Pará</option>
    <option value="PB">Paraíba</option>
    <option value="PR">Paraná</option>
    <option value="PE">Pernambuco</option>
    <option value="PI">Piauí</option>
    <option value="RJ">Rio de Janeiro</option>
    <option value="RN">Rio Grande do Norte</option>
    <option value="RS">Rio Grande do Sul</option>
    <option value="RO">Rondônia</option>
    <option value="RR">Roraima</option>
    <option value="SC">Santa Catarina</option>
    <option value="SP">São Paulo</option>
    <option value="SE">Sergipe</option>
    <option value="TO">Tocantins</option>
    <option value="EX">Exterior</option>
            </select>
          </div>

        <!--Botão de finalizar cadastro -->
        <div class="button" style="text-align: center;"> 
          <button class="botaofinaliza" type="submit" >FINALIZAR CADASTRO  </button>
        </div>
        <?php echo form_close(); ?>
</form>
  

        <a href="<?= base_url().'index.php/Agendamento/exibirDadosCliente'?>" class="fecharModal">&times;</a>

    </div>
  </div>

  <!-- <script src="<?= base_url('public/js/jquery3.6.min.js')?>"></script> -->
  <script src="<?= base_url('public/js/jquery.min.js')?>"></script>
  <script src="<?= base_url('public/js/mask/jquery.mask.min.js')?>"></script>
  <script src="<?= base_url('public/js/mask/Mascara.js') ?>"></script>
  <script src="<?= base_url('public/js/snackbar.js') ?>"></script>
  <script type="text/javascript">
  let CPF = document.querySelector("#cpfcliente");
  let invalid = document.querySelector("#invalid");


function ValidaCPF() {
 let aux = CPF.value;
 console.log("aux" + aux);
 let varCpf = aux.replace(".", "").replace(".", "").replace("-","");
 console.log("var" + varCpf);

 let soma = 0;
 let verificador1 = 0;
 let verificador2 = 0;

 for (let index = 0, valor = 10; index < 9; index++, valor--) {
     soma += varCpf[index] * valor;
 }

 verificador1 = soma * 10 % 11;

 if (verificador1 == 10) {
     verificador1 = 0;
 }


//------------------------------------------------
soma = 0;
for (let index = 0, valor = 11; index < 9; index++, valor--) {
soma += varCpf[index] * valor;
}
soma += verificador1 * 2;

verificador2 = soma * 10 % 11;

if (verificador2 == 10) {
verificador2 = 0;
}


if (verificador1 != varCpf[9] || verificador2 != varCpf[10]) {
    CPF.value= "";
    invalid.removeAttribute("hidden");
}else if(
varCpf[0]==varCpf[1] &&
varCpf[1]==varCpf[2] &&
varCpf[2]==varCpf[3] &&
varCpf[3]==varCpf[4] &&
varCpf[4]==varCpf[5] &&
varCpf[5]==varCpf[6] &&
varCpf[6]==varCpf[7] &&
varCpf[7]==varCpf[8] &&
varCpf[8]==varCpf[9] &&
varCpf[9]==varCpf[10]){

CPF.value= "";
invalid.classList.add("alinha-feedback");
invalid.removeAttribute("hidden");

}else{
    invalid.classList.remove("alinha-feedback");
    invalid.setAttribute("hidden", true);
}
}
</script>
</body>

</html>

