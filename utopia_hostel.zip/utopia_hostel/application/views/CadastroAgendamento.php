<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <link rel="stylesheet" type="text/css" href="<?= base_url().'public/css/menulateral.css'?>">
    <link rel="stylesheet" type="text/css" href="<?= base_url().'public/css/agendamento.css'?>">
    <link rel="stylesheet" type="text/css" href="<?= base_url().'public/css/snackbar.css'?>">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Lato:ital,wght@0,100;0,300;0,400;0,700;0,900;1,100;1,300;1,400;1,700;1,900&display=swap" rel="stylesheet">

    <title>Agendamento</title>
</head>
<body>
    <div class="app">
    <div class="sidebar">
        <div class="logo_content">
            <div class="logo">
                <div class="logo_name">Utopia Hostel</div>
            </div>
            <i class='bx bx-menu bx-flip-horizontal' id="btn" ></i>
        </div>
        <ul class="nav_list">
            <li>
                <a href="<?=base_url().'index.php/cadastrarAgendamento'?>">
                    <i class='bx bx-book'></i>
                    <span class="links_name">Agendamento</span>
                </a>
                <span class="tooltip">Agendamento</span>
            </li>
            <li>
                <a href="<?=base_url().'index.php/exibeAgendamentos'?>">
                    <i class='bx bx-calendar-check'></i>
                    <span class="links_name">Check-in</span>
                </a>
                <span class="tooltip">Check-in</span>
            </li>
            <li>
            <a href="<?=base_url().'index.php/checkout'?>">
                    <i class='bx bx-exit'></i>
                    <span class="links_name">Check-out</span>
                </a>
                <span class="tooltip">Check-out</span>
            </li>
            <li>
            <a href="<?=base_url().'index.php/dashboard'?>">
            <i class='bx bx-line-chart'></i>
                    <span class="links_name">Dashboard</span>
                </a>
                <span class="tooltip">Dashboard</span>
            </li>
        </ul>
    </div>
    <div class="agd">
    <div class="alinha titulo-icon">
        <i class='bx bx-book'></i>
        <h1 id="titulo">AGENDAMENTO</h1>
    </div>
    
    <?php   echo validation_errors();     ?>
    
    <?php if(isset($mensagensErro)) echo "<div class='snackbar-erro' >".$mensagensErro."</div>"; ?>
    <?php if(isset($mensagensSucesso)) echo "<div class='snackbar-sucesso' >".$mensagensSucesso."</div>"; ?>

    <?php  echo form_open('index.php/Agendamento/cadastrarAgendamento'); ?>
        <div class="clt alinha agendamento">
            <label for="cliente">CLIENTE</label>
            <input type="search" id="cliente" name="cliente" list="clientes" autocomplete="true" required>
        <datalist id="clientes" role="select">
    <?php 
   $this->load->model("ClienteModel");
    $carregarClientes = $this->ClienteModel->exibirClientes();
    if($carregarClientes != NULL){
      foreach($carregarClientes->result_array() as $clientes){ ?>
      <option value="<?= $clientes["cliNome"]; ?>"></option>
      <?php } 
    }else{
        ?>
        <option value="<?='Selecione' ?>"></option>
        <?php
    }
      ?>
      </datalist>
      
            <button class="botaoclt"><a href="<?= base_url().'index.php/Cliente/#abrirmodal'?>" >NOVO CLIENTE</a></button>
        </div>

        <div class="quarto alinha agendamento">
            <label for="qrtEscolhido">QUARTO ESCOLHIDO</label>
            <select name="qrtEscolhido" id="qrtEscolhido" name="qrtEscolhido" required onclick="adicionaTudo(this)">
                <option value=1>Rock</option>
                <option value=2>Egito</option>
                <option value=3>Zoológico</option>
                <option value=4>Tropicália</option>
            </select>
    
            <label for="qtdPessoas">PESSOAS</label>
            <input type="number" id="qtdPessoas"  name="qtdPessoas" required min="1" max="15" value="1" onchange="adicionaTudo(this)">
        </div>
    
    

    <fieldset class="datas agendamento">
        <legend>DATAS PREVISTAS:</legend>
    <div class="date alinha agendamento">
            <label for="checkin">CHECK-IN</label>
            <input type="date" id="checkin" name="checkin" min="<?= date('Y-m-d')?>" required onclick="adicionaTudo(this)">
        
            <label for="checkout" id="checkout-label">CHECK-OUT</label>
            <input type="date" id="checkout" name="checkout" min="<?= date('Y-m-d')?>" onclick="adicionaTudo(this)">
        </div>
        <small hidden class="feedback-invalido"  style="text-align: center;" id="invalidDate">A data de Checkout não pode ser anterior à data de Checkin.</small>
    </fieldset>

    <fieldset class="obs alinha agendamento">
        <legend>OBSERVAÇÕES:</legend>
    
            <textarea id="obs" name="obs" ></textarea>
        
    </fieldset>
    
        <div class="valores alinha agendamento">
            <label for="valorpago">VALOR PAGO</label>
    <input type="number" id="valorpago" name="valorpago" step="0.01" value="0"  onclick="adicionaTudo(this)" onchange="adicionaTudo(this)">
    <small hidden class="feedback-invalido"  style="text-align: center;" id="invalidTotal">O valor pago não pode ser maior que o valor total.</small>

            <label for="valoraberto">VALOR EM ABERTO</label>
            <input type="number" id="valoraberto" name="valoraberto" step="0.01" value="0" readonly onchange="adicionaTudo(this)">
            <small hidden class="feedback-invalido"  style="text-align: center;" id="invalidAberto">O valor em aberto não pode ser negativo.</small>

            <label for="valortotal">VALOR TOTAL</label>
            <input type="number" id="valortotal"  name="valortotal" step="0.01" value="0"  readonly required onchange="adicionaTudo(this)">
            <small hidden class="feedback-invalido"  style="text-align: center;" id="invalidTotal">O valor total não pode ser negativo.</small>
        </div>

        <div class="adicionais alinha agendamento" id="add" >
            <div>
            <input type="checkbox" id="toalha" name="toalha" value="toalha" onclick="adicionaTudo(this)">
            <label for="toalha">TOALHA</label>
        </div>
            <div>
            <input type="checkbox" id="estacionamento" name="estacionamento" value="estacionamento" onclick="adicionaTudo(this)">
            <label for="estacionamento">ESTACIONAMENTO</label>
            </div>
            <div>
            <input type="checkbox" id="cobertor" name="cobertor" value="cobertor" onclick="adicionaTudo(this)">
            <label for="cobertor">COBERTOR</label>
      </div>
            <button class="botaoagd" type="submit">AGENDAR</button>   
        </div>
        
        <?php echo form_close(); ?>
</div>
</div>
</body>


<script src="<?= base_url('public/js/jquery.min3.6.js')?>"></script>
<script src="<?= base_url('public/js/jquery.min.js')?>"></script>
<script src="<?= base_url('public/js/mask/jquery.mask.min.js')?>"></script>
  <script src="<?= base_url('public/js/mask/Mascara.js') ?>"></script>
  <script src="<?= base_url('public/js/snackbar.js') ?>"></script>
  <script src="<?= base_url('public/js/moment.js') ?>"></script>
  <script src="<?= base_url('public/js/moment-with-locales.min.js') ?>"></script>
  <script type="text/javascript">

  btn = document.getElementById("btn");
sidebar = document.querySelector(".sidebar");

        btn.onclick = function(){
            sidebar.classList.toggle("active");
        }
 </script>
<script type="text/javascript">
//data    

     valorPago = 0;
     valorCamaQuarto = 0;
     valorAdicional = 0;
     valorAberto=0;
     toalha = 5.00, cobertor = 10.00, estacionamento = 15.00;
    //colocar valor dos quartos
    valortotal=document.getElementById('valortotal');
    valoraberto=document.getElementById('valoraberto');
    valorjapago = 0;
function selecionaQuarto(){
var elementoQuarto = document.getElementById("qrtEscolhido");
var quarto = elementoQuarto.options[elementoQuarto.selectedIndex].text;
//var opcaoValor = select.options[select.selectedIndex].value;

switch(quarto){
    case 'Rock':
        valorCamaQuarto = 90.00;
    break;
    case 'Egito':
        valorCamaQuarto = 90.00;
    break;
    case 'Zoológico':
        valorCamaQuarto = 90.00;
    break;
    case 'Tropicália':
        valorCamaQuarto = 90.00;
    break;
}
return valorCamaQuarto, quarto;

}

function quantidadePessoas(){

    pessoas = 0;

    var elementoPessoas = document.getElementById("qtdPessoas");
    pessoas = elementoPessoas.value;
   // console.log(pessoas);
    return pessoas;
}

function adiciona(){

// tem q fazer na mesma função pra ele não zerar
valorAdicional = 0;

$.each($("input[type='checkbox']:checked"), function(){         
    if(this.value == 'toalha'){
       valorAdicional = valorAdicional+toalha;
   }else if(this.value == 'estacionamento'){
    valorAdicional = valorAdicional+estacionamento;
   }else if(this.value == 'cobertor'){
    valorAdicional = valorAdicional+cobertor;
   }else{
       valorAdicional = 0;
   }
});

    return valorAdicional;
}

 function valorPag(){
    valorjapago = document.getElementById('valorpago').value;
    valorPago = valorjapago;
    return valorPago;
 }
function valorEmAberto(valorTotal, valorPago){
   valorAberto = valorTotal - valorPago;
   valoraberto.value = valorAberto;
 return valorAberto;

}


$('[type="date"]').on("keydown", function() {
  event.preventDefault();
  return false;
});



function Fcheckin(){
    let checkin = document.getElementById("checkin");
    DTcheckin = new Date(checkin.value);
    console.log(checkin);

    return DTcheckin;
}
function Fcheckout(){
    let checkout = document.getElementById("checkout");
    DTcheckout = new Date(checkout.value);
    console.log(checkout);
    return DTcheckout;

}
  
   
function verificaDatas(){
Fcheckin();
Fcheckout();
var diffMilissegundos = DTcheckout - DTcheckin;
qtdDias = diffMilissegundos / 1000/60/60/24;

console.log(qtdDias+ "");

let invalidDate = document.querySelector("#invalidDate");
if(qtdDias <= 0){
    invalidDate.removeAttribute("hidden");
}else{  
    invalidDate.setAttribute("hidden", true);
}

return qtdDias;

}

function adicionaTudo(){

    quantidadePessoas();
    selecionaQuarto();
    verificaDatas();
    adiciona();
    console.log(qtdDias);
    if(valorAdicional != 0){
   valorTotal =  (valorAdicional + (valorCamaQuarto*pessoas*qtdDias));
   valorAberto = valorTotal - valorPago;

    }else{
        valorTotal =  (0 + (valorCamaQuarto*pessoas*qtdDias));
        valorAberto = valorTotal - valorPago;

    }
    valortotal.value = valorTotal;
   console.log(valorTotal); 

 //  valorAberto = valorTotal - valorPago;
   valoraberto.value = valorAberto;

   valorPago = document.getElementById('valorpago').value;

   

  
   console.log("em aberto"+valorAberto);
    //  console.log(valorAdicional+ " "+ valorCamaQuarto + " "+ pessoas);
    
}

</script>
</html>
