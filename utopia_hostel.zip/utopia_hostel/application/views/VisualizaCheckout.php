<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Lato:ital,wght@0,100;0,300;0,400;0,700;0,900;1,100;1,300;1,400;1,700;1,900&display=swap" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="<?= base_url().'public/css/checkin.css'?>">
    <link rel="stylesheet" type="text/css" href="<?= base_url().'public/css/menulateral.css'?>">
    <link rel="stylesheet" type="text/css" href="<?= base_url().'public/css/agendamento.css'?>">
    <link rel="stylesheet" type="text/css" href="<?= base_url().'public/css/tooltip.css'?>">

    
    <title>Check-out</title>
</head>
<body> <div class="app">
    <div class="sidebar">
        <div class="logo_content">
            <div class="logo">
                <div class="logo_name">Utopia Hostel</div>
            </div>
            <i class='bx bx-menu bx-flip-horizontal' id="btn" ></i>
        </div>
        <ul class="nav_list">
            <li>
                <a href="<?=base_url().'index.php/cadastrarAgendamento'?>">
                    <i class='bx bx-book'></i>
                    <span class="links_name">Agendamento</span>
                </a>
                <span class="tooltip">Agendamento</span>
            </li>
            <li>
                <a href="<?=base_url().'index.php/exibeAgendamentos'?>">
                    <i class='bx bx-calendar-check'></i>
                    <span class="links_name">Check-in</span>
                </a>
                <span class="tooltip">Check-in</span>
            </li>
            <li>
            <a href="<?=base_url().'index.php/checkout'?>">
                    <i class='bx bx-exit'></i>
                    <span class="links_name">Check-out</span>
                </a>
                <span class="tooltip">Check-out</span>
            </li>
            <li>
            <a href="<?=base_url().'index.php/dashboard'?>">
            <i class='bx bx-line-chart'></i>
                    <span class="links_name">Dashboard</span>
                </a>
                <span class="tooltip">Dashboard</span>
            </li>
        </ul>
    </div>
    <div>
    
    <div class="checkin">
    <div class="titulo-icon">
        <i class='bx bx-calendar-check'></i>
        <h1 id="titulo">CHECKOUT</h1>
    </div>

    <div>
        <!-- <button class="botaodia" type="button">2 DIAS</button> -->
        <p>AGENDAMENTOS PARA HOJE</p>
    </div>

    <?php
    $this->load->model("CheckoutModel");
    
    $age = $this->CheckoutModel->exibirCheckins();/*fazer join*/
    if($age != NULL){
    ?>
    <?php   echo validation_errors();     ?>
        <?php if(isset($mensagens)) echo $mensagens; ?>
        <small id="erro" class="feedback-invalido" hidden>O valor pago não pode ser maior que o valor em aberto</small>
        <?php echo form_open('index.php/Checkout/confirmaCheckout'); ?>
    <div class="tabela">
    <table class="table-zebra">
    <!-- ver aqui -->
        <thead>
          <tr>
            <th>CÓD</th>
            <th>NOME</th>
            <th>DOCUMENTO</th>
            <th>QUARTO</th>
            <th>N°HOSPEDES</th>
            <th>VALOR EM ABERTO 
            <div class="tooltip">
            <i class='bx bxs-help-circle'></i>
                <span>Dê um clique e digite o valor pago. O valor será calculado ao confirmar o checkin.</span>
            </div>
                </th>
            <th>CHECKOUT</th>
          </tr>
        </thead>
        <tbody class="table-zebra__body">
        <?php
        foreach($age as $agenda){
          ?>
          <tr>
              <form action="confirmaCheckout.php" method="POST"> 
                <td name="codigo" id="codigo" value="<?=$agenda['ageCodigo'] ?>" data-codigo="<?php echo $agenda['ageCodigo'];?>"><?php echo $agenda['ageCodigo'];?></td>
                <td><?php echo $agenda['cliNome'];?></td>
                <td><?php echo $agenda['cliCPF']."/".$agenda['cliRG']?></td>
                <td><?php echo $agenda['quaNomeQuarto'];?></td>
                <td><?php echo $agenda['ageQtdPessoas'];?></td>
                <td id="valoraberto" class="valor" name="valoraberto#<?=$agenda['ageCodigo'] ?>"  data-valor="<?php echo $agenda['ageValorAberto'];?>" data-placeholder="<?php echo $agenda['ageValorAberto'];?>" contenteditable="true"><?php echo $agenda['ageValorAberto'];?></td>
                <td class="select-container"><input type="checkbox" id="checkout"></td>
        </form>
          </tr>
          <?php  }
      }else{
          echo "Não há chekouts para mostrar!";
      }
       ?>
                </tbody>
                </table>
            </div>

            <div class="btncheckin">
                <button type="submit" id="botao" name="botao" onclick="pegaDados()">CONFIRMAR</button>
            </div>
        </div>
    </div>
    <?php echo form_close(); ?>
</body>
<script src="<?= base_url('public/js/jquery.min3.6.js')?>"></script>
<script src="<?= base_url('public/js/jquery.min.js')?>"></script>
<script src="//ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>

<script>


    let btn = document.querySelector("#btn");
    let sidebar = document.querySelector(".sidebar");
    let valor = 0;
    btn.onclick = function(){
        sidebar.classList.toggle("active");
    }

    //let V = document.querySelector("valor");
  let erro = document.querySelector("#erro");


const ele = document.getElementsByClassName("valor");
console.log(ele);
for(i=0; i<ele.length; i++){
    const placeholder = ele[i].getAttribute('data-placeholder');

ele[i].innerHTML === '' && (ele[i].innerHTML = placeholder);
ele[i].addEventListener('click', function (e) {
    const valor = e.target.innerHTML;
    valor === placeholder && (e.target.innerHTML = '');    
});
ele[i].addEventListener('blur', function (e) {
    const value = e.target.innerHTML;
    valor === '' && (e.target.innerHTML = placeholder);
});

ele[i].addEventListener('blur', function (e) {

const valor = e.target.innerHTML;
 if(valor > placeholder){
    e.target.innerHTML = "";

erro.classList.add("alinha-feedback");
erro.removeAttribute("hidden");
        }else{
    erro.classList.remove("alinha-feedback");
    erro.setAttribute("hidden", true);
        }

    });
}


$(".valor").keypress(function(e) {
    if (isNaN(String.fromCharCode(e.which))) e.preventDefault();
});

function pegaDados(){
   var tabela =  document.querySelector('.table-zebra__body');
   // console.log(tabela.rows.length);
   // console.log(tabela);
//console.log(tabela.rows[0].cells[6].firstChild.value);
    var dadosTabela = [];
    for(i = 0; i<tabela.rows.length; i++){
       let dadoLinha = {
            codigo:tabela.rows[i].cells[0].textContent.trim(),
            valoraberto:tabela.rows[i].cells[5].textContent.trim(),
            check:tabela.rows[i].cells[6].getElementsByTagName('input')[0].checked == true ? tabela.rows[i].cells[6].getElementsByTagName('input')[0].checked : null
        };
        console.log(dadoLinha);
        if(dadoLinha.check != null){
        dadosTabela.push(dadoLinha);  
        }else{

        }      

    }
    console.log(dadosTabela);

    document.cookie = 'cookieCheckout=' + btoa(JSON.stringify((dadosTabela)));
    
}


</script>
</html>