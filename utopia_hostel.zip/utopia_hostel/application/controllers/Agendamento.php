
<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Agendamento extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		$this->load->helper(array('form', 'url'));
		$this->load->database();
	//	$this->CI =& get_instance();
	}

	public function index()
	{
		$this->load->helper(['form','url']);
		$this->load->library('form_validation');
	}
	
	public function exibirDadosCliente(){
		//acho q nao precisa, mas ok
		$this->load->helper(['form','url']);
		$this->load->library('form_validation');
		$this->load->model('ClienteModel');
		$modelo = $this->ClienteModel->exibirClientes();
		$this->load->view("CadastroAgendamento");
	}
	
	public function exibeDadosAgendamento(){
		$this->load->helper(['form','url']);
		$this->load->library('form_validation');

		$this->load->model('AgendamentoModel');
		$modelo = $this->AgendamentoModel->exibirAgendamentos();
		$this->load->view("VisualizaAgendamento");
	}


	public function verificaDataCheckin(){
		if($agendamento['ageDataCheckin'] < date('Y-m-d')){
			$respostaIn = "Data Inválida";
			$agendamento['ageDataCheckin'] = "";
		}else{
			$respostaIn = "";
		}
		return $respostaIn;
	}

	public function verificaDataCheckout(){
		if($agendamento['ageDataCheckout'] != null)
		if($agendamento['ageDataCheckout'] < date('Y-m-d')){
			$respostaOut = "Data Inválida";
			$agendamento['ageDataCheckout'] = "";
		}else{
			$respostaOut = "";
		}
		return $respostaOut;
	}
	
	public function cadastrarAgendamento(){
	
	   $this->load->helper(['form','url']);
		$this->load->library('form_validation');
		$this->load->database();
		$this->load->model('ClienteModel');
		$this->load->model('AgendamentoModel');
		$this->load->library('javascript');
		//VER AQUI
		

		$cliNome = $this->input->post('cliente');
			
		$cod= $this->ClienteModel->buscarCodigoCliente($cliNome);
		$toalha= isset($_POST['toalha']);
		$estacionamento= isset($_POST['estacionamento']);
		$cobertor= isset($_POST['cobertor']);
		

		
		$dadosAgendamento= array(
			'cliCodigo' => $cod,
			'quaCodigoQuarto' => $this->input->post('qrtEscolhido'),
			'ageQtdPessoas' => $this->input->post('qtdPessoas'),
			'ageToalha' => $toalha,
			'ageEstacionamento' => $estacionamento,
			'ageCobertor' => $cobertor,
			'ageDataCheckin' => date_format(new DateTime($this->input->post('checkin')), 'Y-m-d'),
			'ageDataCheckout' => date_format(new DateTime($this->input->post('checkout')), 'Y-m-d'),
			'ageValorTotal' => $this->input->post('valortotal'),
			'ageValorPago' => $this->input->post('valorpago'),
			'ageValorAberto' => $this->input->post('valoraberto'),
			'ageStatus' => $this->input->post('status'),
			'ageReservado' => $this->input->post('Reservado'),
			'ageObservacao' => $this->input->post('obs')
		);
		$ageDataCheckin = $dadosAgendamento['ageDataCheckin'];
		$ageDataCheckout = $dadosAgendamento['ageDataCheckout'];
		

		function data($ageDataCheckin,$ageDataCheckout){
			$CI =& get_instance();	
			$CI->load->helper(['form','url']);
			$CI->load->library('form_validation');
			$CI->load->database();
			$CI->load->model('ClienteModel');
			$CI->load->model('AgendamentoModel');
			
		if($ageDataCheckout > $ageDataCheckin){
		 $CI->form_validation->set_message('data', "<div class='feedback-invalido'>Data de checkout não pode ser menor que a data de checkin.</div>");
			return false;
			}else{	
			return true;
		}
	}
	
		$this->form_validation->set_rules('cliente','Cliente','required',
			array('required' =>"<div class='feedback-invalido'>Cliente Inexistente</div>"));
		
		$this->form_validation->set_rules('qrtEscolhido','Quarto','required',
			array('required' =>"<div class='feedback-invalido'>Preenchimento do Quarto obrigatório.</div>"));
		
		$this->form_validation->set_rules('qtdPessoas','Pessoas','required',
		array('required' => "<div class='feedback-invalido'>Preenchimento da quantidade de pessoas obrigatório.</div>"));

	$this->form_validation->set_rules('checkin','Checkin','required',
		array('required' => "<div class='feedback-invalido'>Preenchimento da Data de Checkin obrigatória</div>"));
		
		$this->form_validation->set_rules('checkout','Checkout','required|data['.$ageDataCheckin.','.$ageDataCheckout.']',
		array('required' => "<div class='feedback-invalido'>Preenchimento da Data de Checkout obrigatória</div>"));

		$this->form_validation->set_rules('valortotal','Valor Total','required|is_natural',
			array('required' => "<div class='feedback-invalido'>Preenchimento do valor total obrigatório</div>",
			'is_natural' => "<div class='feedback-invalido'>O valor total não pode ser negativo.</div>"));
		
	$this->form_validation->set_rules('valoraberto','Valor em Aberto','required|is_natural',
			array('required' => "<div class='feedback-invalido'>Preenchimento do valor aberto obrigatório</div>",
			'is_natural' => "<div class='feedback-invalido'>O valor em aberto não pode ser negativo.</div>"));
			
	$this->form_validation->set_rules('valorpago','Valor Pago','required|is_natural',
			array('required' => "<div class='feedback-invalido'>Preenchimento do valor pago obrigatório</div>",
			'is_natural' => "<div class='feedback-invalido'>O valor pago não pode ser maior que o valor total.</div>"));
	
		
		if($this->form_validation->run() == FALSE){
			$this->load->helper(['form','url']);
			$this->load->library('form_validation');
			$this->load->model('AgendamentoModel');
			//echo $this->error_log();
			$forms= $this->AgendamentoModel->exibirAgendamentos();
			$this->load->view("CadastroAgendamento",$forms);	
			}else if($cod == null){	
			$this->load->helper(['form','url']);
			$this->load->library('form_validation');
			$this->load->model('AgendamentoModel');
			//echo $this->error_log();
			$mensagensErro = array('mensagensErro' => "Cliente não cadastrado.</div>");
			$this->AgendamentoModel->exibirAgendamentos();
			$this->load->view("CadastroAgendamento",$mensagensErro);
			}else{
				$this->load->model('AgendamentoModel');
				$retorno =$this->AgendamentoModel->cadastrarAgendamento($dadosAgendamento);
				$mensagensSucesso = array('mensagensSucesso' => "Agendamento cadastrado com sucesso.");
	$this->load->view('CadastroAgendamento', $mensagensSucesso);	
	}

}



	//ver aqui
	/*public function calculoValorAberto($dadosAgendamento){
		$valorAberto = $dadosAgendamento['ageValorTotal'] - $dadosAgendamento['ageValorPago'];
		return $valorAberto;
	}*/

public function confirmaCheckin(){

	$this->load->helper(['form','url']);
	$this->load->library('form_validation');
	$this->load->database();
	$this->load->model('ClienteModel');
	$this->load->model('AgendamentoModel');


$dados = $_COOKIE['cookieCheckin'];
$atualizaAgendamento = array();

$informacoes = base64_decode($dados);
$valores = json_decode($informacoes);

for($i=0;$i<sizeof($valores);$i++){
	$atualizaAgendamento['ageValorPago'] = $valores[$i]->valoraberto;
	$atualizaAgendamento['ageStatus'] = 1;
	$atualizaAgendamento['ageCodigo'] = $valores[$i]->codigo;
	
	$modelo = $this->AgendamentoModel->exibirAgendamentos();
	//print_r($modelo);
	
	//if($atualizaAgendamento['ageValorPago'] <= $modelo['ageValorAberto']){
		if($this->AgendamentoModel->atualizaValores($atualizaAgendamento)){
			echo "deu certo o update!";
		}else{	
			$error = $this->db->error(); 
		 }
		/*}else{
			$mensagens = array('mensagensErro' => "O valor digitado nao pode ser maior que o valor em aberto!");
		}*/
}
unset($_COOKIE['cookieCheckin']);
setcookie('cookieCheckin', null, -1);

	$this->load->view("VisualizaAgendamento");
}
}

