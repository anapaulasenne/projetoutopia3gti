<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Cliente extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		$this->load->helper(array('form', 'url'));
		$this->load->database();

	}

	public function index()
	{
		$this->load->helper(['form','url']);
		$this->load->library('form_validation');
		$this->load->view("CadastroCliente");
	}
	public function exibeDadosClientes(){
		$this->load->helper(['form','url']);
		$this->load->library('form_validation');

		$this->load->model('ClienteModel');
		$modelo = $this->ClienteModel->exibirClientes();
		$this->load->view("VisualizaCliente");
	}
	
	public function cadastrarClientes(){
		//carrega os helpers
		$this->load->helper(['form','url']);
		$this->load->library('form_validation');
		$this->load->database();

		
	
		$cliente = array(
			'cliNome' => $this->input->post('cliNome'),
			'cliRG' => $this->input->post('cliRG'),
			'cliCPF' => $this->input->post('cliCPF'),
			'cliTelefone' => $this->input->post('cliTelefone'),
			'cliCelular' => $this->input->post('cliCelular'),
			'cliEmail' => $this->input->post('cliEmail'),
			'cliNascimento' => date_format(new DateTime($this->input->post('cliNascimento')), 'Y-m-d'),
			'cliEstado' => $this->input->post('cliEstado'),
			'cliCidade' => $this->input->post('cliCidade')
		);
	//print_r($cliente);

	
		$cliNascimento = $cliente['cliNascimento'];

		function data($cliNascimento){
			//print_r($cliNascimento);
			$CI =& get_instance();	
			$CI->load->helper(['form','url']);
			$CI->load->library('form_validation');
			$CI->load->database();
			$CI->load->model('ClienteModel');
			$CI->load->model('AgendamentoModel');
		
$date = date_create();
$data = date_modify($date, '-18 years');
$data = $data->format('Y-m-d');
//ver aqui
		if($cliNascimento >  $data){
	   // print_r($data);
	//	print_r($cliNascimento);
		 $CI->form_validation->set_message('data', "<div class='feedback-invalido'>Você deve ter no minimo 18 anos para realizar o cadastro</div>");
			return false;
			}else{	
			return true;
		}
		}
		 $this->form_validation->set_rules('cliNome','Nome','required|min_length[2]|max_length[150]',
			array('required' => "<div class='feedback-invalido'>Preenchimento do Nome é obrigatório</div>",
				  'min_length' => "<div class='feedback-invalido'>O tamanho mínimo do Nome é <b>2</b> caracteres</div>",
				  'max_length' => "<div class='feedback-invalido'>O tamanho máximo do Nome é <b>150</b> caracteres</div>"));
		
		$this->form_validation->set_rules('cliCPF','CPF','required|exact_length[14]|regex_match[/(\d-.)/]',
			array('required' => "<div class='feedback-invalido'>Preenchimento do CPF obrigatorio.</div>",
				'exact_length'=>"<div class='feedback-invalido'>O CPF deve ser escrito com <b>11</b> números</div>",
				'regex_match'=>"<div class='feedback-invalido'>O CPF é um campo numérico</div>"));
		
		//ver regex para RG
		$this->form_validation->set_rules('cliNascimento','DATA NASCIMENTO','required|data['.$cliNascimento.']',
		array('required' => "<div class='feedback-invalido'>Preenchimento da Data de Nascimento é obrigatória</div>"));

		$this->form_validation->set_rules('cliRG','RG','min_length[11]|regex_match[/(\d-.)/]',
		array('min_length'=>"<div class='feedback-invalido'>O RG deve ser escrito com no minimo <b>9</b> números</div>",
							'regex_match'=>"<div class='feedback-invalido'>O RG deve obedecer a regra <code>xx.xxx.xxx-x</code>.</div>"));
					//email
		$this->form_validation->set_rules('cliEmail','Email','required|trim|valid_email',
		array('required' => "<div class='feedback-invalido'>Preenchimento do Email obrigatorio.</div>",
		'valid_email' => "<div class='feedback-invalido'>Por favor, digite um email valido. Ex:. <code> xxxxxx@xxxx.com </code></div>"));
		//telefone
		$this->form_validation->set_rules('cliTelefone','Telefone', 'exact_length[14]|trim',
		array('exact_length'=>"<div class='feedback-invalido'>O Telefone deve ser escrito com <b>10</b> números</div>"));

		$this->form_validation->set_rules('cliCelular','Celular','min_length[14]|max_length[15]|trim',
		array(	'min_length'=>"<div class='feedback-invalido'>O campo Celular deve conter no minimo <b>10</b> números</div>",
		'max_length'=>"<div class='feedback-invalido'>O campo Celular deve conter no maximo <b>11</b> números</div>"));

		/*8$this->form_validation->set_rules('cliEstado','Estado','required',		
		array('required' => "<div class='feedback-invalido'>Preenchimento do Estado é obrigatóri</div>"));*/

		$this->form_validation->set_rules('cliCidade','Cidade');
		
			
		if($this->form_validation->run() == FALSE){
			$this->load->helper(['form','url']);
			$this->load->library('form_validation');
			$this->load->model('ClienteModel');
			$forms= $this->ClienteModel->exibirClientes();
		
		$this->load->view("CadastroCliente",$forms);	
		
	}else{
			$dadosPessoais=preg_replace('/[\(\)\.\-\<\>\"\/\\\\]/','',$dadosPessoais=array(
				'cliNome' => $this->input->post('cliNome'),
				'cliCPF' => $this->input->post('cliCPF'),	
				'cliRG' => $this->input->post('cliRG'),
				'cliTelefone' => $this->input->post('cliTelefone'),
				'cliCelular' => $this->input->post('cliCelular')
			));

			$dataNascimento = array('cliNascimento' => $this->input->post('cliNascimento'));

			$dadosEndereco = preg_replace('/[\(\)\.\-\<\>\"\/\\\\]/','',$dadosEndereco=array(
				'cliCidade' => $this->input->post('cliCidade'),
				'cliEstado' => $this->input->post('cliEstado')
			));	
			$email=preg_replace('/[\(\)\<\>\"\/\\\\]/','',$email=array('cliEmail'=>$this->input->post('cliEmail')));

			$dadosCliente = $dadosPessoais + $email+ $dataNascimento + $dadosEndereco;

		//print_r($dadosCliente);
		
		$this->load->model('ClienteModel');
		$validarCliente=$this->ClienteModel->validarCliente($dadosCliente);
	
		if($validarCliente){
				$mensagensErro = array('mensagensErro' => "Usuário já cadastrado!");
				$this->load->view('CadastroCliente',$mensagensErro);		

			}else{
			
				$this->load->model('ClienteModel');
				$this->ClienteModel->cadastrarClientes($dadosCliente);
				$mensagensSucesso = array('mensagensSucesso' => "Cliente cadastrado com sucesso.");
				
				//falta o parametro da modal
				$this->load->view('CadastroCliente',$mensagensSucesso);	
}

}
}
		
}
