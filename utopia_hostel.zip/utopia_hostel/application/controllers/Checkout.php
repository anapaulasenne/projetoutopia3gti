
<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Checkout extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		$this->load->helper(array('form', 'url'));
		$this->load->database();
	//	$this->CI =& get_instance();
	}

	public function index()
	{
		$this->load->helper(['form','url']);
		$this->load->library('form_validation');
	}
	

    public function exibeDadosCheckin(){
		$this->load->helper(['form','url']);
		$this->load->library('form_validation');

		$this->load->model('CheckoutModel');
		$modelo = $this->CheckoutModel->exibirCheckins();
        $this->load->view("VisualizaCheckout");
	}


public function confirmaCheckout(){

$this->load->helper(['form','url']);
$this->load->library('form_validation');
$this->load->database();
$this->load->model('ClienteModel');
$this->load->model('CheckoutModel');


$dados = $_COOKIE['cookieCheckout'];
$atualizaAgendamento = array();

$informacoes = base64_decode($dados);
$valores = json_decode($informacoes);

for($i=0;$i<sizeof($valores);$i++){
$atualizaAgendamento['ageValorPago'] = $valores[$i]->valoraberto;
$atualizaAgendamento['ageStatus'] = 0;
$atualizaAgendamento['ageCodigo'] = $valores[$i]->codigo;


    if($this->CheckoutModel->confirmaCheckout($atualizaAgendamento)){
        echo "deu certo o update!";
    }else{	
        $error = $this->db->error(); 
     }

}
unset($_COOKIE['cookieCheckout']);
setcookie('cookieCheckout', null, -1);

$this->load->view("VisualizaCheckout");
}

function teste(){
	$this->load->model("AgendamentoModel");
	$this->load->database();

$datas = $this->AgendamentoModel->faixa1994();
//echo $datas;
$this->load->view("VisualizaDashboard");
}
}