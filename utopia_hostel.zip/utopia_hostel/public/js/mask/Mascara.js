$('.cep').mask('00000-000');
$('.cnpj').mask('00.000.000/0000-00', {reverse: true});
$('.telefone').mask('(00) 0000-0000'); //ver mascara
$('.cpf').mask('000.000.000-00', {reverse: true});
$('.rg').mask('000.000.00-A',{translation:  {'A': {pattern: /[0-9xX]/,reverse: true }}}); //ok
$(".dataCheckin").mask("99/99/9999");
$(".dataCheckout").mask("99/99/9999");

/*var telefone = function(val){
    return val.replace(/[0-9+]/+g, '').length === 15 ?  '+000 (000) 00000-0000' : '+000 (000) 0000-0000';
    //ver outros codigos de area
},
DDIOptions = {
    onKeyPress: function(val, e, field, options) {
    field.mask(telefone.apply({}, arguments), options);
    }
    };
    $('.telefone').mask(telefone, DDIOptions);
*/

var cel = function (val) {
    return val.replace(/\D/g, '').length === 11 ? '(00) 00000-0000' : '(00) 0000-00009';
},
spOptions = {
    onKeyPress: function (val, e, field, spOptions) {
        field.mask(cel.apply({}, arguments), spOptions);
    }
};

$('.sp_celphones').mask(cel, spOptions);